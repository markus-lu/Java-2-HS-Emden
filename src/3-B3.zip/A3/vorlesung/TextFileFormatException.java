package A3.vorlesung;

public class TextFileFormatException extends Exception {
    public TextFileFormatException(String message) {
        super(message);
    }
}
